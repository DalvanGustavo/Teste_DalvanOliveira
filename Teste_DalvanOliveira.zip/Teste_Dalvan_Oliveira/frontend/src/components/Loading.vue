<template>
  <div class="loading">Carregando...</div>
</template>